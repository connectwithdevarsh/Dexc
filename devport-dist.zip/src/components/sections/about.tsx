export default function About() {
  return (
    <section id="about" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 fade-in-up">
          <p className="text-indigo-600 dark:text-indigo-400 font-medium mb-2">Get to know me</p>
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">About Me</h2>
          <div className="w-24 h-1 bg-gradient-primary mx-auto rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 fade-in-left">
            <div className="glassmorphism p-8 rounded-3xl">
              <h3 className="text-2xl font-bold mb-4 text-indigo-600 dark:text-indigo-400">
                <i className="fas fa-user-graduate mr-3"></i>
                My Story
              </h3>
              <p className="text-lg leading-relaxed mb-4">
                I'm a passionate and hardworking IT student currently pursuing a Diploma in Information Technology. I love learning about web development and building creative projects using Python, Flask, HTML, CSS, and JavaScript.
              </p>
              <p className="text-lg leading-relaxed">
                My goal is to become a successful software developer and make a meaningful impact in the tech industry. I believe in consistency, growth, and helping others through technology.
              </p>
            </div>
            
            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-6">
              <div className="glassmorphism text-center p-6 rounded-2xl hover:scale-105 transition-all duration-300">
                <div className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent mb-2">3+</div>
                <div className="text-gray-600 dark:text-gray-400 font-medium">Semesters Completed</div>
              </div>
              <div className="glassmorphism text-center p-6 rounded-2xl hover:scale-105 transition-all duration-300">
                <div className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">8+</div>
                <div className="text-gray-600 dark:text-gray-400 font-medium">Technologies Learning</div>
              </div>
            </div>
          </div>
          
          <div className="fade-in-right">
            {/* Professional journey visualization */}
            <div className="glassmorphism p-8 rounded-3xl">
              <h3 className="text-2xl font-bold mb-8 text-indigo-600 dark:text-indigo-400">
                <i className="fas fa-route mr-3"></i>
                My Journey
              </h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4 group">
                  <div className="gradient-primary w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-all duration-300">
                    <i className="fas fa-graduation-cap text-xl"></i>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-lg mb-1">Student & Learner</h4>
                    <p className="text-gray-600 dark:text-gray-400">Pursuing Diploma in IT at RC Technical Institute</p>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-2">
                      <div className="gradient-primary h-2 rounded-full" style={{width: '75%'}}></div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4 group">
                  <div className="gradient-secondary w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-all duration-300">
                    <i className="fas fa-code text-xl"></i>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-lg mb-1">Developer</h4>
                    <p className="text-gray-600 dark:text-gray-400">Building projects with Python, Web Technologies</p>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-2">
                      <div className="gradient-secondary h-2 rounded-full" style={{width: '60%'}}></div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4 group">
                  <div className="bg-gradient-to-r from-green-500 to-emerald-500 w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-all duration-300">
                    <i className="fas fa-rocket text-xl"></i>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-lg mb-1">Future Goal</h4>
                    <p className="text-gray-600 dark:text-gray-400">Becoming a Professional Software Engineer</p>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-2">
                      <div className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full" style={{width: '30%'}}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
