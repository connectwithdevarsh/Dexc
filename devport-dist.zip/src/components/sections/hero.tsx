import { useEffect, useState } from "react";

const typingTexts = [
  "Python Developer",
  "Web Designer", 
  "IT Student",
  "Future Software Engineer"
];

export default function Hero() {
  const [currentTextIndex, setCurrentTextIndex] = useState(0);
  const [currentText, setCurrentText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const typeSpeed = 100;
    const deleteSpeed = 50;
    const pauseTime = 2000;

    const type = () => {
      const fullText = typingTexts[currentTextIndex];
      
      if (!isDeleting) {
        setCurrentText(fullText.substring(0, currentText.length + 1));
        
        if (currentText === fullText) {
          setTimeout(() => setIsDeleting(true), pauseTime);
        }
      } else {
        setCurrentText(fullText.substring(0, currentText.length - 1));
        
        if (currentText === "") {
          setIsDeleting(false);
          setCurrentTextIndex((prev) => (prev + 1) % typingTexts.length);
        }
      }
    };

    const timer = setTimeout(type, isDeleting ? deleteSpeed : typeSpeed);
    return () => clearTimeout(timer);
  }, [currentText, isDeleting, currentTextIndex]);

  return (
    <section id="home" className="min-h-screen flex items-center relative overflow-hidden pt-20">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-r from-indigo-400 to-purple-400 rounded-full opacity-20 floating blur-xl"></div>
        <div className="absolute top-40 right-20 w-24 h-24 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-20 floating blur-xl" style={{animationDelay: '-2s'}}></div>
        <div className="absolute bottom-40 left-20 w-40 h-40 bg-gradient-to-r from-blue-400 to-indigo-400 rounded-full opacity-20 floating blur-xl" style={{animationDelay: '-4s'}}></div>
        <div className="absolute bottom-20 right-10 w-20 h-20 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full opacity-20 floating blur-xl" style={{animationDelay: '-3s'}}></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div className="space-y-8 fade-in-left">
            <div className="space-y-4">
              <p className="text-lg font-medium text-indigo-600 dark:text-indigo-400">Welcome to my portfolio</p>
              <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
                Hi, I'm{' '}
                <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  Devarsh
                </span>
              </h1>
              <div className="text-2xl lg:text-3xl font-semibold text-gray-700 dark:text-gray-300 min-h-[3rem] flex items-center">
                <span className="mr-2">I'm a</span>
                <span className="text-indigo-600 dark:text-indigo-400 typing-cursor">
                  {currentText}
                </span>
              </div>
            </div>
            
            <p className="text-lg lg:text-xl text-gray-600 dark:text-gray-400 max-w-2xl leading-relaxed">
              Passionate IT student pursuing a Diploma in Information Technology. I love building creative solutions with Python, web technologies, and exploring the endless possibilities of software development.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="gradient-primary text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 hover:transform hover:scale-105 hover:shadow-xl shadow-indigo-500/30"
              >
                <i className="fas fa-user-tie mr-2"></i>
                Hire Me
              </button>
              <button
                onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
                className="glassmorphism text-gray-700 dark:text-gray-300 border-2 border-indigo-200 dark:border-indigo-700 px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 hover:transform hover:scale-105"
              >
                <i className="fas fa-eye mr-2"></i>
                View Projects
              </button>
            </div>
            
            {/* Social Links */}
            <div className="flex space-x-4 pt-4">
              <a
                href="https://www.linkedin.com/in/sathiya-devarsh-11654b375"
                target="_blank"
                rel="noopener noreferrer"
                className="glassmorphism w-12 h-12 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400 hover:scale-110 transition-all duration-300"
              >
                <i className="fab fa-linkedin text-xl"></i>
              </a>
              <a
                href="mailto:connectwithdevarsh@gmail.com"
                className="glassmorphism w-12 h-12 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400 hover:scale-110 transition-all duration-300"
              >
                <i className="fas fa-envelope text-xl"></i>
              </a>
              <a
                href="#"
                className="glassmorphism w-12 h-12 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400 hover:scale-110 transition-all duration-300"
              >
                <i className="fab fa-github text-xl"></i>
              </a>
            </div>
          </div>
          
          {/* Profile Photo */}
          <div className="flex justify-center lg:justify-end fade-in-right">
            <div className="relative">
              <div className="w-80 h-80 lg:w-96 lg:h-96 relative">
                {/* Glowing Background */}
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full blur-xl opacity-30 pulse-glow"></div>
                
                {/* Image Container */}
                <div className="relative w-full h-full glassmorphism rounded-full p-2">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800" 
                    alt="Devarsh Sathiya - IT Student and Future Software Engineer" 
                    className="w-full h-full object-cover rounded-full" 
                  />
                </div>
                
                {/* Floating Tech Icons */}
                <div className="absolute -top-4 -right-4 gradient-primary text-white p-4 rounded-full shadow-lg floating pulse-glow">
                  <i className="fas fa-code text-xl"></i>
                </div>
                <div className="absolute -bottom-4 -left-4 gradient-secondary text-white p-4 rounded-full shadow-lg floating pulse-glow" style={{animationDelay: '-1s'}}>
                  <i className="fab fa-python text-xl"></i>
                </div>
                <div className="absolute top-1/2 -left-6 transform -translate-y-1/2 glassmorphism text-indigo-600 dark:text-indigo-400 p-3 rounded-full floating" style={{animationDelay: '-2s'}}>
                  <i className="fas fa-laptop-code text-lg"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <button
          onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
          className="glassmorphism p-4 rounded-full text-indigo-600 dark:text-indigo-400 hover:scale-110 transition-all duration-300"
        >
          <i className="fas fa-chevron-down text-xl"></i>
        </button>
      </div>
    </section>
  );
}
