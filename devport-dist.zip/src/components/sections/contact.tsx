import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

const contactLinks = [
  {
    href: "mailto:connectwithdevarsh@gmail.com",
    icon: "fas fa-envelope",
    title: "Email",
    description: "connectwithdevarsh@gmail.com",
    color: "bg-red-500"
  },
  {
    href: "https://www.linkedin.com/in/sathiya-devarsh-11654b375",
    icon: "fab fa-linkedin",
    title: "LinkedIn",
    description: "Connect professionally",
    color: "bg-blue-600"
  }
];

export default function Contact() {
  const [formData, setFormData] = useState<ContactFormData>({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  
  const { toast } = useToast();

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      const response = await apiRequest("POST", "/api/contacts", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Message Sent!",
        description: data.message || "Thank you! I'll get back to you soon.",
      });
      setFormData({ name: "", email: "", subject: "", message: "" });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    contactMutation.mutate(formData);
  };

  return (
    <section id="contact" className="py-20 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-40 h-40 bg-gradient-to-r from-indigo-400 to-purple-400 rounded-full opacity-10 floating blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-10 floating blur-3xl" style={{animationDelay: '-2s'}}></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16 fade-in-up">
          <p className="text-indigo-600 dark:text-indigo-400 font-medium mb-2">Let's work together</p>
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">Get In Touch</h2>
          <div className="w-24 h-1 bg-gradient-primary mx-auto rounded-full"></div>
          <p className="text-lg text-gray-600 dark:text-gray-400 mt-4 max-w-2xl mx-auto">
            Ready to discuss your next project or just want to say hello? I'd love to hear from you!
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Information */}
          <div className="space-y-8 fade-in-left">
            <div className="glassmorphism p-8 rounded-3xl">
              <h3 className="text-2xl font-bold mb-6 text-indigo-600 dark:text-indigo-400">
                <i className="fas fa-comments mr-3"></i>
                Let's Connect
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-8 leading-relaxed">
                I'm always excited to discuss new opportunities, collaborate on interesting projects, or connect with fellow developers and technology enthusiasts.
              </p>
              
              {/* Quick Contact Stats */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="text-center p-4 glassmorphism rounded-2xl">
                  <div className="text-2xl font-bold text-indigo-600 dark:text-indigo-400 mb-1">
                    <i className="fas fa-clock"></i>
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Response within 24h</div>
                </div>
                <div className="text-center p-4 glassmorphism rounded-2xl">
                  <div className="text-2xl font-bold text-indigo-600 dark:text-indigo-400 mb-1">
                    <i className="fas fa-handshake"></i>
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Open to collaborations</div>
                </div>
              </div>
            </div>
            
            {/* Contact Links */}
            <div className="space-y-4">
              {contactLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  target={link.href.startsWith('http') ? "_blank" : undefined}
                  rel={link.href.startsWith('http') ? "noopener noreferrer" : undefined}
                  className="glassmorphism flex items-center space-x-4 p-6 rounded-2xl hover:scale-105 transition-all duration-300 group"
                >
                  <div className={`w-14 h-14 ${link.color} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-all duration-300 shadow-lg`}>
                    <i className={`${link.icon} text-white text-xl`}></i>
                  </div>
                  <div className="flex-1">
                    <div className="font-bold text-lg group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{link.title}</div>
                    <div className="text-gray-600 dark:text-gray-400">{link.description}</div>
                  </div>
                  <i className="fas fa-arrow-right text-gray-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 group-hover:translate-x-1 transition-all duration-300"></i>
                </a>
              ))}
              
              <div className="glassmorphism flex items-center space-x-4 p-6 rounded-2xl">
                <div className="w-14 h-14 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <i className="fas fa-map-marker-alt text-white text-xl"></i>
                </div>
                <div className="flex-1">
                  <div className="font-bold text-lg">Location</div>
                  <div className="text-gray-600 dark:text-gray-400">Ahmedabad, Gujarat, India</div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Contact Form */}
          <div className="fade-in-right">
            <div className="glassmorphism p-8 rounded-3xl">
              <h3 className="text-2xl font-bold mb-6 text-indigo-600 dark:text-indigo-400">
                <i className="fas fa-paper-plane mr-3"></i>
                Send a Message
              </h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-gray-700 dark:text-gray-300 mb-2 block font-medium">Your Name</Label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      className="glassmorphism border-2 border-indigo-200 dark:border-indigo-700 focus:border-indigo-500 dark:focus:border-indigo-400 rounded-xl h-12"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-gray-700 dark:text-gray-300 mb-2 block font-medium">Your Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      className="glassmorphism border-2 border-indigo-200 dark:border-indigo-700 focus:border-indigo-500 dark:focus:border-indigo-400 rounded-xl h-12"
                      placeholder="john@example.com"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="subject" className="text-gray-700 dark:text-gray-300 mb-2 block font-medium">Subject</Label>
                  <Input
                    id="subject"
                    name="subject"
                    type="text"
                    required
                    value={formData.subject}
                    onChange={handleInputChange}
                    className="glassmorphism border-2 border-indigo-200 dark:border-indigo-700 focus:border-indigo-500 dark:focus:border-indigo-400 rounded-xl h-12"
                    placeholder="Project Discussion"
                  />
                </div>
                
                <div>
                  <Label htmlFor="message" className="text-gray-700 dark:text-gray-300 mb-2 block font-medium">Message</Label>
                  <Textarea
                    id="message"
                    name="message"
                    rows={5}
                    required
                    value={formData.message}
                    onChange={handleInputChange}
                    className="glassmorphism border-2 border-indigo-200 dark:border-indigo-700 focus:border-indigo-500 dark:focus:border-indigo-400 rounded-xl resize-none"
                    placeholder="Tell me about your project or just say hello!"
                  />
                </div>
                
                <Button
                  type="submit"
                  disabled={contactMutation.isPending}
                  className="w-full gradient-primary text-white font-bold py-4 px-6 rounded-xl text-lg transition-all duration-300 hover:scale-105 hover:shadow-xl shadow-indigo-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {contactMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Sending Message...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-paper-plane mr-2"></i>
                      Send Message
                    </>
                  )}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
