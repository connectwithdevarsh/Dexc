interface Project {
  title: string;
  description: string;
  image: string;
  technologies: string[];
  demoLink?: string;
  codeLink?: string;
  status: "completed" | "in-progress" | "planned";
}

const projects: Project[] = [
  {
    title: "Modern Web Portfolio",
    description: "Responsive portfolio website with glassmorphism design, dark mode, and smooth animations built with React and TypeScript.",
    image: "https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
    technologies: ["React", "TypeScript", "Tailwind CSS"],
    status: "completed"
  },
  {
    title: "Python Flask Web App",
    description: "Full-stack web application with user authentication, database integration, and RESTful API built with Flask framework.",
    image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
    technologies: ["Python", "Flask", "SQLite", "HTML/CSS"],
    status: "in-progress"
  },
  {
    title: "Database Management System",
    description: "Comprehensive DBMS project implementing ER diagrams, normalization, and complex SQL queries for college management.",
    image: "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
    technologies: ["SQL", "SQLite", "Database Design"],
    status: "planned"
  }
];

const technologyGradients: { [key: string]: string } = {
  "React": "from-blue-400 to-blue-600",
  "TypeScript": "from-blue-600 to-indigo-600",
  "Tailwind CSS": "from-cyan-400 to-blue-500",
  "Python": "from-blue-500 to-yellow-500",
  "Flask": "from-gray-700 to-gray-900",
  "SQLite": "from-gray-600 to-gray-800",
  "HTML/CSS": "from-orange-500 to-red-500",
  "SQL": "from-green-500 to-emerald-600",
  "Database Design": "from-purple-500 to-indigo-600",
};

const statusColors = {
  "completed": "from-green-500 to-emerald-600",
  "in-progress": "from-yellow-500 to-orange-500", 
  "planned": "from-purple-500 to-indigo-600"
};

const statusIcons = {
  "completed": "fas fa-check-circle",
  "in-progress": "fas fa-clock",
  "planned": "fas fa-lightbulb"
};

export default function Projects() {
  return (
    <section id="projects" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 fade-in-up">
          <p className="text-indigo-600 dark:text-indigo-400 font-medium mb-2">My work</p>
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">Featured Projects</h2>
          <div className="w-24 h-1 bg-gradient-primary mx-auto rounded-full"></div>
          <p className="text-lg text-gray-600 dark:text-gray-400 mt-4 max-w-2xl mx-auto">
            Explore my latest projects showcasing various technologies and creative solutions
          </p>
        </div>
        
        {/* Coming Soon Message */}
        <div className="text-center mb-12 fade-in-up">
          <div className="glassmorphism p-8 rounded-3xl max-w-md mx-auto">
            <div className="gradient-primary w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 pulse-glow">
              <i className="fas fa-rocket text-white text-3xl"></i>
            </div>
            <h3 className="text-2xl font-bold mb-4">More Projects Coming Soon!</h3>
            <p className="text-gray-600 dark:text-gray-400">
              I'm actively working on exciting projects. Check back soon for updates and live demos!
            </p>
          </div>
        </div>
        
        {/* Project Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="project-card glassmorphism rounded-3xl overflow-hidden fade-in-up group">
              <div className="relative overflow-hidden">
                <img 
                  src={project.image} 
                  alt={`${project.title} - ${project.description}`}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-all duration-500" 
                />
                <div className="absolute top-4 right-4">
                  <div className={`bg-gradient-to-r ${statusColors[project.status]} text-white px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-2`}>
                    <i className={`${statusIcons[project.status]} text-xs`}></i>
                    <span className="capitalize">{project.status.replace('-', ' ')}</span>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3">{project.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4 leading-relaxed">{project.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.technologies.map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className={`px-3 py-1 text-sm rounded-full bg-gradient-to-r ${technologyGradients[tech] || 'from-gray-500 to-gray-600'} text-white font-medium`}
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                
                <div className="flex space-x-3">
                  <button className="flex-1 gradient-primary text-white py-3 px-4 rounded-xl font-semibold transition-all duration-300 hover:scale-105 hover:shadow-lg">
                    <i className="fas fa-eye mr-2"></i>
                    Live Demo
                  </button>
                  <button className="flex-1 glassmorphism border-2 border-indigo-200 dark:border-indigo-700 text-gray-700 dark:text-gray-300 py-3 px-4 rounded-xl font-semibold transition-all duration-300 hover:scale-105">
                    <i className="fab fa-github mr-2"></i>
                    Code
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
