interface EducationItem {
  title: string;
  institution: string;
  duration: string;
  status: "completed" | "current" | "upcoming";
  description: string;
  subjects: string[];
  icon: string;
  gradient: string;
  year: string;
}

const educationData: EducationItem[] = [
  {
    title: "Diploma in Information Technology",
    institution: "RC Technical Institute, Ahmedabad",
    duration: "2022 - 2025",
    status: "current",
    year: "Currently in 3rd Semester",
    description: "Comprehensive program covering modern IT concepts including programming, web development, database management, and software engineering principles.",
    subjects: ["Python Programming", "Web Development", "Database Systems", "System Analysis", "Network Fundamentals"],
    icon: "fas fa-graduation-cap",
    gradient: "from-indigo-500 to-purple-600"
  },
  {
    title: "Secondary School Certificate (SSC)",
    institution: "Shree Satuababa School, Palitana",
    duration: "2020 - 2022",
    status: "completed",
    year: "Completed 2022",
    description: "Strong academic foundation with excellent performance in science and mathematics, which sparked my interest in technology and computer science.",
    subjects: ["Mathematics", "Science", "Computer Applications", "English"],
    icon: "fas fa-school",
    gradient: "from-green-500 to-emerald-600"
  }
];

const learningGoals = [
  {
    title: "Advanced Java Programming",
    description: "Mastering OOP concepts and enterprise Java development",
    icon: "fab fa-java",
    gradient: "from-red-500 to-orange-600"
  },
  {
    title: "Full-Stack Web Development",
    description: "Building modern web applications with latest frameworks",
    icon: "fas fa-code",
    gradient: "from-blue-500 to-indigo-600"
  },
  {
    title: "Database Design & Optimization",
    description: "Advanced SQL, database normalization and performance tuning",
    icon: "fas fa-database",
    gradient: "from-purple-500 to-pink-600"
  },
  {
    title: "Cloud Computing & DevOps",
    description: "Learning cloud platforms and deployment automation",
    icon: "fas fa-cloud",
    gradient: "from-cyan-500 to-blue-600"
  }
];

const subjectGradients: { [key: string]: string } = {
  "Python Programming": "from-blue-500 to-yellow-500",
  "Web Development": "from-purple-500 to-pink-500",
  "Database Systems": "from-green-500 to-emerald-600",
  "System Analysis": "from-orange-500 to-red-500",
  "Network Fundamentals": "from-indigo-500 to-purple-600",
  "Mathematics": "from-blue-500 to-indigo-600",
  "Science": "from-green-500 to-teal-600",
  "Computer Applications": "from-purple-500 to-indigo-600",
  "English": "from-pink-500 to-rose-600",
};

const statusConfig = {
  "completed": { 
    color: "from-green-500 to-emerald-600",
    icon: "fas fa-check-circle",
    label: "Completed"
  },
  "current": { 
    color: "from-blue-500 to-indigo-600",
    icon: "fas fa-play-circle",
    label: "In Progress"
  },
  "upcoming": { 
    color: "from-purple-500 to-indigo-600",
    icon: "fas fa-clock",
    label: "Upcoming"
  }
};

export default function Education() {
  return (
    <section id="education" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 fade-in-up">
          <p className="text-indigo-600 dark:text-indigo-400 font-medium mb-2">My academic journey</p>
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">Education</h2>
          <div className="w-24 h-1 bg-gradient-primary mx-auto rounded-full"></div>
          <p className="text-lg text-gray-600 dark:text-gray-400 mt-4 max-w-2xl mx-auto">
            My educational background and continuous learning journey in technology
          </p>
        </div>
        
        <div className="max-w-5xl mx-auto">
          {/* Timeline */}
          <div className="relative mb-16">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-indigo-500 to-purple-600 rounded-full hidden md:block"></div>
            
            {educationData.map((item, index) => (
              <div key={index} className={`relative ${index === educationData.length - 1 ? '' : 'mb-16'} fade-in-up`}>
                <div className={`flex flex-col md:flex-row items-center ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                  {/* Timeline Node */}
                  <div className="absolute left-1/2 transform -translate-x-1/2 w-16 h-16 rounded-full border-4 border-white dark:border-gray-800 shadow-xl z-10 hidden md:flex items-center justify-center">
                    <div className={`w-full h-full bg-gradient-to-r ${item.gradient} rounded-full flex items-center justify-center`}>
                      <i className={`${item.icon} text-white text-xl`}></i>
                    </div>
                  </div>
                  
                  {/* Content Card */}
                  <div className={`w-full md:w-5/12 ${index % 2 === 0 ? 'md:pr-8' : 'md:pl-8'}`}>
                    <div className="glassmorphism p-8 rounded-3xl hover:scale-105 transition-all duration-500 group">
                      {/* Mobile Timeline Icon */}
                      <div className="flex md:hidden items-center mb-4">
                        <div className={`w-12 h-12 bg-gradient-to-r ${item.gradient} rounded-2xl flex items-center justify-center mr-4`}>
                          <i className={`${item.icon} text-white text-lg`}></i>
                        </div>
                        <div className={`bg-gradient-to-r ${statusConfig[item.status].color} text-white px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-2`}>
                          <i className={`${statusConfig[item.status].icon} text-xs`}></i>
                          <span>{statusConfig[item.status].label}</span>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-start mb-4">
                        <h3 className="text-xl font-bold group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{item.title}</h3>
                        <div className={`hidden md:block bg-gradient-to-r ${statusConfig[item.status].color} text-white px-3 py-1 rounded-full text-sm font-medium`}>
                          <i className={`${statusConfig[item.status].icon} mr-1 text-xs`}></i>
                          {statusConfig[item.status].label}
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <p className="font-semibold text-indigo-600 dark:text-indigo-400">{item.institution}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400 mt-1">
                          <span><i className="fas fa-calendar mr-1"></i>{item.duration}</span>
                          <span><i className="fas fa-info-circle mr-1"></i>{item.year}</span>
                        </div>
                      </div>
                      
                      <p className="text-gray-600 dark:text-gray-400 mb-4 leading-relaxed">{item.description}</p>
                      
                      <div className="flex flex-wrap gap-2">
                        {item.subjects.map((subject, subjectIndex) => (
                          <span 
                            key={subjectIndex}
                            className={`px-3 py-1 text-sm rounded-full bg-gradient-to-r ${subjectGradients[subject] || 'from-gray-500 to-gray-600'} text-white font-medium`}
                          >
                            {subject}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Learning Goals */}
          <div className="fade-in-up">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold mb-4">Current Learning Focus</h3>
              <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                Technologies and skills I'm actively learning to advance my career in software development
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {learningGoals.map((goal, index) => (
                <div key={index} className="glassmorphism p-6 rounded-2xl hover:scale-105 transition-all duration-300 text-center group">
                  <div className={`w-16 h-16 bg-gradient-to-r ${goal.gradient} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-all duration-300 shadow-lg`}>
                    <i className={`${goal.icon} text-white text-2xl`}></i>
                  </div>
                  <h4 className="font-bold mb-2 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{goal.title}</h4>
                  <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">{goal.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
