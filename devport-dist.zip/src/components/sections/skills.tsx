import { useEffect, useState } from "react";

interface SkillData {
  name: string;
  percentage: number;
  color: string;
  icon: string;
}

interface SkillCategory {
  title: string;
  icon: string;
  gradient: string;
  skills: SkillData[];
}

const skillsData: SkillCategory[] = [
  {
    title: "Programming Languages",
    icon: "fas fa-code",
    gradient: "from-blue-500 to-indigo-600",
    skills: [
      { name: "Python", percentage: 85, color: "from-blue-500 to-blue-600", icon: "fab fa-python" },
      { name: "HTML5 & CSS3", percentage: 80, color: "from-orange-500 to-red-500", icon: "fab fa-html5" },
      { name: "JavaScript", percentage: 65, color: "from-yellow-400 to-yellow-600", icon: "fab fa-js" },
      { name: "Java", percentage: 45, color: "from-red-500 to-red-600", icon: "fab fa-java" },
    ]
  },
  {
    title: "Web Development",
    icon: "fas fa-globe",
    gradient: "from-purple-500 to-pink-600",
    skills: [
      { name: "Responsive Design", percentage: 75, color: "from-purple-500 to-purple-600", icon: "fas fa-mobile-alt" },
      { name: "Bootstrap", percentage: 60, color: "from-purple-400 to-purple-500", icon: "fab fa-bootstrap" },
      { name: "Frontend Design", percentage: 70, color: "from-pink-500 to-purple-600", icon: "fas fa-palette" },
    ]
  },
  {
    title: "Database & CS Fundamentals",
    icon: "fas fa-database",
    gradient: "from-green-500 to-emerald-600",
    skills: [
      { name: "SQLite & DBMS", percentage: 70, color: "from-green-500 to-green-600", icon: "fas fa-database" },
      { name: "Data Structures", percentage: 60, color: "from-green-400 to-emerald-500", icon: "fas fa-project-diagram" },
      { name: "OOP Concepts", percentage: 55, color: "from-emerald-500 to-teal-600", icon: "fas fa-cubes" },
    ]
  }
];

const tools = [
  { icon: "fab fa-github", name: "GitHub", color: "text-gray-800 dark:text-gray-200" },
  { icon: "fas fa-cloud", name: "Replit, Netlify", color: "text-blue-500" },
  { icon: "fas fa-mobile-alt", name: "Pydroid3", color: "text-green-500" },
  { icon: "fas fa-paint-brush", name: "Canva, Figma", color: "text-purple-500" },
];

export default function Skills() {
  const [animatedSkills, setAnimatedSkills] = useState<Set<string>>(new Set());

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const progressBars = entry.target.querySelectorAll('.skill-progress');
            progressBars.forEach((bar: Element, index: number) => {
              const htmlBar = bar as HTMLElement;
              const width = htmlBar.getAttribute('data-width');
              const skillName = htmlBar.getAttribute('data-skill');
              if (width && skillName && !animatedSkills.has(skillName)) {
                setTimeout(() => {
                  htmlBar.style.width = width;
                  setAnimatedSkills(prev => new Set(prev).add(skillName));
                }, index * 200);
              }
            });
          }
        });
      },
      { threshold: 0.3 }
    );

    const skillsSection = document.getElementById('skills');
    if (skillsSection) {
      observer.observe(skillsSection);
    }

    return () => observer.disconnect();
  }, [animatedSkills]);

  return (
    <section id="skills" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 fade-in-up">
          <p className="text-indigo-600 dark:text-indigo-400 font-medium mb-2">What I know</p>
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">Skills & Technologies</h2>
          <div className="w-24 h-1 bg-gradient-primary mx-auto rounded-full"></div>
          <p className="text-lg text-gray-600 dark:text-gray-400 mt-4 max-w-2xl mx-auto">
            Technologies and skills I'm passionate about and continuously improving
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillsData.map((category, categoryIndex) => (
            <div key={categoryIndex} className="glassmorphism p-8 rounded-3xl hover:scale-105 transition-all duration-500 fade-in-up group">
              <div className="flex items-center mb-8">
                <div className={`w-16 h-16 bg-gradient-to-r ${category.gradient} rounded-2xl flex items-center justify-center mr-4 shadow-lg group-hover:scale-110 transition-all duration-300`}>
                  <i className={`${category.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-xl font-bold">{category.title}</h3>
              </div>
              <div className="space-y-6">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="group/skill">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <i className={`${skill.icon} text-lg text-gray-600 dark:text-gray-400`}></i>
                        <span className="font-medium">{skill.name}</span>
                      </div>
                      <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">{skill.percentage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 overflow-hidden">
                      <div 
                        className={`bg-gradient-to-r ${skill.color} h-3 rounded-full skill-progress shadow-sm`}
                        data-width={`${skill.percentage}%`}
                        data-skill={`${categoryIndex}-${skillIndex}`}
                        style={{ width: '0%' }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Tools & Platforms */}
          <div className="glassmorphism p-8 rounded-3xl hover:scale-105 transition-all duration-500 fade-in-up group md:col-span-2 lg:col-span-1">
            <div className="flex items-center mb-8">
              <div className="w-16 h-16 bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center mr-4 shadow-lg group-hover:scale-110 transition-all duration-300">
                <i className="fas fa-tools text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold">Tools & Platforms</h3>
            </div>
            <div className="grid grid-cols-1 gap-4">
              {tools.map((tool, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 rounded-xl hover:bg-white/20 dark:hover:bg-gray-800/20 transition-all duration-300 group/tool">
                  <div className="w-10 h-10 glassmorphism rounded-full flex items-center justify-center group-hover/tool:scale-110 transition-all duration-300">
                    <i className={`${tool.icon} ${tool.color}`}></i>
                  </div>
                  <span className="font-medium">{tool.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
