const socialLinks = [
  {
    icon: "fab fa-linkedin",
    href: "https://www.linkedin.com/in/sathiya-devarsh-11654b375",
    color: "from-blue-500 to-blue-600",
    label: "LinkedIn"
  },
  {
    icon: "fas fa-envelope",
    href: "mailto:connectwithdevarsh@gmail.com",
    color: "from-green-500 to-emerald-600",
    label: "Email"
  },
  {
    icon: "fab fa-github",
    href: "#",
    color: "from-gray-600 to-gray-700",
    label: "GitHub"
  },
  {
    icon: "fab fa-telegram",
    href: "https://t.me/devarshdev",
    color: "from-blue-400 to-cyan-500",
    label: "Telegram"
  }
];

const quickLinks = [
  { name: 'Home', id: 'home', icon: 'fas fa-home' },
  { name: 'About', id: 'about', icon: 'fas fa-user' },
  { name: 'Skills', id: 'skills', icon: 'fas fa-code' },
  { name: 'Projects', id: 'projects', icon: 'fas fa-folder-open' },
  { name: 'Education', id: 'education', icon: 'fas fa-graduation-cap' },
  { name: 'Contact', id: 'contact', icon: 'fas fa-envelope' }
];

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="relative py-20 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 left-1/4 w-32 h-32 bg-gradient-to-r from-indigo-400 to-purple-400 rounded-full opacity-10 floating blur-3xl"></div>
        <div className="absolute bottom-10 right-1/4 w-24 h-24 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-10 floating blur-3xl" style={{animationDelay: '-3s'}}></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About Section */}
          <div className="lg:col-span-2">
            <div className="glassmorphism p-8 rounded-3xl">
              <h3 className="text-3xl font-bold mb-4">
                <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Devarsh</span>
                <span className="text-indigo-500 dark:text-indigo-400">.</span>
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
                Passionate IT student dedicated to creating innovative solutions and contributing to the tech community. Always learning, always growing.
              </p>
              <div className="flex flex-wrap gap-3">
                {socialLinks.map((link, index) => (
                  <a
                    key={index}
                    href={link.href}
                    target={link.href.startsWith('http') ? "_blank" : undefined}
                    rel={link.href.startsWith('http') ? "noopener noreferrer" : undefined}
                    className={`group flex items-center space-x-2 bg-gradient-to-r ${link.color} text-white px-4 py-2 rounded-full font-medium transition-all duration-300 hover:scale-110 hover:shadow-lg`}
                    title={link.label}
                  >
                    <i className={`${link.icon} text-sm`}></i>
                    <span className="text-sm">{link.label}</span>
                  </a>
                ))}
              </div>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <div className="glassmorphism p-6 rounded-3xl h-full">
              <h3 className="text-xl font-bold mb-6 text-indigo-600 dark:text-indigo-400">
                <i className="fas fa-link mr-2"></i>
                Quick Links
              </h3>
              <ul className="space-y-3">
                {quickLinks.map((item, index) => (
                  <li key={index}>
                    <button
                      onClick={() => document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth' })}
                      className="flex items-center space-x-3 text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all duration-300 group w-full text-left"
                    >
                      <i className={`${item.icon} text-sm group-hover:scale-110 transition-transform`}></i>
                      <span className="group-hover:translate-x-1 transition-transform">{item.name}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          {/* Contact Info */}
          <div>
            <div className="glassmorphism p-6 rounded-3xl h-full">
              <h3 className="text-xl font-bold mb-6 text-indigo-600 dark:text-indigo-400">
                <i className="fas fa-address-card mr-2"></i>
                Contact Info
              </h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-gray-600 dark:text-gray-400">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                    <i className="fas fa-envelope text-white text-xs"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Email</p>
                    <p className="text-xs">connectwithdevarsh@gmail.com</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 text-gray-600 dark:text-gray-400">
                  <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                    <i className="fas fa-map-marker-alt text-white text-xs"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Location</p>
                    <p className="text-xs">Ahmedabad, Gujarat</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 text-gray-600 dark:text-gray-400">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center">
                    <i className="fas fa-graduation-cap text-white text-xs"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Status</p>
                    <p className="text-xs">IT Student & Developer</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Bottom Section */}
        <div className="mt-12 pt-8 border-t border-gray-200 dark:border-gray-700">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="flex items-center space-x-2 text-gray-600 dark:text-gray-400">
              <i className="fas fa-heart text-red-500 pulse-glow"></i>
              <span className="text-sm">
                &copy; {currentYear} Devarsh Sathiya. Built with passion and creativity.
              </span>
            </div>
            
            <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full pulse-glow"></div>
                <span>Available for opportunities</span>
              </div>
              <span>•</span>
              <span>Made with React & TypeScript</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
