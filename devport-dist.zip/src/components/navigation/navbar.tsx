import { useState, useEffect } from "react";
import { useScrollSpy } from "@/hooks/use-scroll-spy";
import ThemeToggle from "@/components/ui/theme-toggle";

const sections = ['home', 'about', 'skills', 'projects', 'education', 'contact'];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const activeSection = useScrollSpy(sections);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'glassmorphism' : ''} p-4`}>
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center">
          <div className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent dark:from-indigo-400 dark:to-purple-400">
            <span className="text-3xl">D</span>evarsh<span className="text-indigo-500 dark:text-indigo-400">.</span>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-1">
            {sections.map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className={`px-4 py-2 rounded-full font-medium capitalize transition-all duration-300 ${
                  activeSection === section 
                    ? 'bg-gradient-primary text-white shadow-lg shadow-indigo-500/30' 
                    : 'text-gray-700 dark:text-gray-300 hover:bg-white/20 hover:text-indigo-600 dark:hover:text-indigo-400'
                }`}
              >
                {section}
              </button>
            ))}
            <ThemeToggle />
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-3">
            <ThemeToggle />
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="glassmorphism p-3 rounded-full hover:scale-110 transition-all duration-300"
            >
              <i className={`fas ${isMobileMenuOpen ? 'fa-times' : 'fa-bars'} text-indigo-600 dark:text-indigo-400`}></i>
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div className={`md:hidden transition-all duration-300 ${isMobileMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}>
        <div className="mt-4 glassmorphism rounded-2xl mx-4 p-4 space-y-2">
          {sections.map((section) => (
            <button
              key={section}
              onClick={() => scrollToSection(section)}
              className={`block w-full text-left px-4 py-3 rounded-xl font-medium capitalize transition-all duration-300 ${
                activeSection === section 
                  ? 'bg-gradient-primary text-white shadow-lg' 
                  : 'text-gray-700 dark:text-gray-300 hover:bg-white/20'
              }`}
            >
              {section}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}
