import { useEffect } from "react";
import Navbar from "@/components/navigation/navbar";
import Hero from "@/components/sections/hero";
import About from "@/components/sections/about";
import Skills from "@/components/sections/skills";
import Projects from "@/components/sections/projects";
import Education from "@/components/sections/education";
import Contact from "@/components/sections/contact";
import Footer from "@/components/common/footer";
import ScrollProgress from "@/components/ui/scroll-progress";
import { useIntersectionObserver } from "@/hooks/use-intersection-observer";

export default function Home() {
  const { observeElement } = useIntersectionObserver();

  useEffect(() => {
    // Observe all fade-in elements
    const fadeElements = document.querySelectorAll('.fade-in-up, .fade-in-left, .fade-in-right');
    fadeElements.forEach(el => observeElement(el as HTMLElement));
  }, [observeElement]);

  return (
    <div className="overflow-x-hidden">
      <ScrollProgress />
      <Navbar />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Education />
        <Contact />
      </main>
      <Footer />
      
      {/* Back to Top Button */}
      <BackToTopButton />
    </div>
  );
}

function BackToTopButton() {
  useEffect(() => {
    const button = document.getElementById('back-to-top');
    
    const handleScroll = () => {
      if (window.scrollY > 300) {
        button?.classList.remove('opacity-0', 'invisible');
        button?.classList.add('opacity-100', 'visible');
      } else {
        button?.classList.add('opacity-0', 'invisible');
        button?.classList.remove('opacity-100', 'visible');
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <button
      id="back-to-top"
      onClick={scrollToTop}
      className="fixed bottom-8 right-8 glassmorphism gradient-primary text-white p-4 rounded-full shadow-xl transition-all duration-300 opacity-0 invisible z-50 hover:scale-110 pulse-glow"
    >
      <i className="fas fa-chevron-up text-lg"></i>
    </button>
  );
}
