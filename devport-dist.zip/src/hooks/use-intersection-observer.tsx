import { useCallback, useRef } from 'react';

export function useIntersectionObserver() {
  const observerRef = useRef<IntersectionObserver | null>(null);

  const observeElement = useCallback((element: HTMLElement) => {
    if (!observerRef.current) {
      observerRef.current = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('visible');
              observerRef.current?.unobserve(entry.target);
            }
          });
        },
        {
          threshold: 0.1,
          rootMargin: '0px 0px -50px 0px'
        }
      );
    }

    observerRef.current.observe(element);
  }, []);

  return { observeElement };
}
