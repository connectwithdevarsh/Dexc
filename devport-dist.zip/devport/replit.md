# Overview

This is a personal portfolio website for Devarsh Sathiya, a Diploma IT student. The application serves as a showcase of his skills, projects, education, and provides a contact form for potential collaborators or employers. The site features a modern, responsive design with smooth animations and interactive elements, presenting information about his programming journey, technical skills, and academic background.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The application uses a React-based frontend with TypeScript, built using Vite for fast development and bundling. The UI is constructed with shadcn/ui components, which provide a modern design system built on top of Radix UI primitives and styled with Tailwind CSS. The frontend follows a single-page application (SPA) pattern with client-side routing handled by Wouter, a lightweight React router.

## Component Structure
The frontend is organized into several key sections:
- **Navigation**: Fixed navbar with smooth scrolling to sections and mobile-responsive menu
- **Content Sections**: Hero, About, Skills, Projects, Education, and Contact sections
- **UI Components**: Reusable components from shadcn/ui for buttons, forms, cards, and other interface elements
- **Hooks**: Custom React hooks for intersection observation, scroll spy functionality, and mobile detection

## Backend Architecture
The backend is built with Express.js and follows a RESTful API pattern. The server includes:
- **Route Registration**: Centralized route handling in `server/routes.ts`
- **Storage Layer**: Abstracted storage interface with in-memory implementation for contact form submissions
- **API Endpoints**: Contact form submission endpoint with validation using Zod schemas
- **External Integration**: Telegram bot integration for real-time contact form notifications

## Data Management
The application uses Drizzle ORM for database schema definition and type-safe database operations, configured for PostgreSQL. However, the current implementation includes a fallback in-memory storage system for contact data. The schema defines a contacts table with fields for name, email, subject, message, and timestamp.

## Form Handling and Validation
Contact form submissions are handled using React Hook Form with Zod validation schemas shared between client and server. The form data is validated on both frontend and backend to ensure data integrity and provide immediate user feedback.

## Styling and Design System
The application uses Tailwind CSS for utility-first styling with a custom design system. CSS variables are used for theming, supporting both light and dark modes. Custom animations and transitions are implemented for enhanced user experience, including fade-in effects, smooth scrolling, and interactive hover states.

## Development Workflow
The project uses Vite for development with hot module replacement, TypeScript for type safety, and ESLint for code quality. The build process generates optimized bundles for production deployment.

# External Dependencies

## UI Framework and Components
- **React**: Core frontend framework with hooks for state management
- **Radix UI**: Primitive components for building accessible UI elements
- **shadcn/ui**: Pre-built component library with consistent design patterns
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Lucide React**: Icon library for modern, customizable icons

## Database and ORM
- **Drizzle ORM**: Type-safe ORM for database operations and schema management
- **PostgreSQL**: Relational database (configured via Neon Database serverless)
- **Drizzle Kit**: CLI tool for database migrations and schema management

## Form Management
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: Schema validation library for runtime type checking
- **@hookform/resolvers**: Integration between React Hook Form and Zod

## Data Fetching
- **TanStack Query**: Server state management with caching and synchronization
- **Fetch API**: Native browser API for HTTP requests

## Development Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Static type checking for JavaScript
- **ESBuild**: Fast JavaScript bundler for production builds

## External Services
- **Telegram Bot API**: Real-time notifications for contact form submissions
- **Google Fonts**: Web fonts for typography (Inter and JetBrains Mono)
- **Font Awesome**: Icon library for social media and contact icons

## Routing and Navigation
- **Wouter**: Lightweight client-side routing library
- **Custom Scroll Spy**: Intersection Observer API for navigation highlighting

## Utilities
- **clsx**: Utility for constructing className strings conditionally
- **class-variance-authority**: Library for creating variant-based component APIs
- **date-fns**: Date utility library for formatting and manipulation