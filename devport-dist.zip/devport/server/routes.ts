import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission
  app.post("/api/contacts", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      
      // Send to Telegram bot
      const telegramMessage = `
🔔 New Contact Form Submission

👤 Name: ${contact.name}
📧 Email: ${contact.email}
📋 Subject: ${contact.subject}

💬 Message:
${contact.message}

---
Sent from Devarsh Sathiya's Portfolio Website
      `;
      
      const botToken = process.env.TELEGRAM_BOT_TOKEN || "8362077901:AAH_UQWCiSrlyUl9W2lkm0Ibjpc4t1IhY_M";
      const chatId = process.env.TELEGRAM_CHAT_ID || "7312733991";
      
      try {
        const telegramResponse = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            chat_id: chatId,
            text: telegramMessage,
            parse_mode: 'HTML'
          })
        });
        
        if (!telegramResponse.ok) {
          console.error('Failed to send to Telegram:', await telegramResponse.text());
        }
      } catch (telegramError) {
        console.error('Telegram API error:', telegramError);
      }
      
      res.json({ 
        success: true, 
        message: "Message sent successfully! I'll get back to you soon." 
      });
    } catch (error) {
      console.error('Contact form error:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "Invalid form data",
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Failed to send message. Please try again." 
        });
      }
    }
  });

  // Get all contacts (optional admin endpoint)
  app.get("/api/contacts", async (req, res) => {
    try {
      const contacts = await storage.getContacts();
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch contacts" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
